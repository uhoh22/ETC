package sp5.sp5chapcboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sp5ChapcBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sp5ChapcBootApplication.class, args);
	}
}
