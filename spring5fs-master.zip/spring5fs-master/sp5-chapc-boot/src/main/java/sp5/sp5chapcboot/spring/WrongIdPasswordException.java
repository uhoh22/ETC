package sp5.sp5chapcboot.spring;

public class WrongIdPasswordException extends RuntimeException {

}
